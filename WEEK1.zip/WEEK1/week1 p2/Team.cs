﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week1_p2
{
    public class Team
    {
       
        List<Programmeur> programmeurs = new List<Programmeur>();

       

        public void AddProgrammeur(Programmeur p)
        {
            p.naam = "";
            p.specialiteit = Specialiteit.Csharp;
            programmeurs.Add(p);


        }

        /*
        public void printalleteamleden()
        {
            Programmeur rohan = new Programmeur();
            rohan.naam = "Rohan van Wijk";
            rohan.specialiteit = Specialiteit.PHP;
            rohan.Print();

            Programmeur steve = new Programmeur();
            steve.naam = "Steve Jobs";
            steve.specialiteit = Specialiteit.Csharp;
            steve.Print();

            Programmeur bill = new Programmeur();
            bill.naam = "Bil Gates";
            bill.specialiteit = Specialiteit.HTML;
            bill.Print();

            Programmeur jan = new Programmeur();
            jan.naam = "Jan Kaas";
            jan.specialiteit = Specialiteit.Java;
            jan.Print();



        }*/

    }
}

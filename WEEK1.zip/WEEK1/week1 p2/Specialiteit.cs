﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week1_p2
{
    public enum Specialiteit
    {
        Java, Csharp, HTML, PHP
    };
}

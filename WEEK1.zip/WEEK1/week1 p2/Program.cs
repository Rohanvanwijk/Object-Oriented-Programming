﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week1_p2
{
    class Program
    {
        static void Main(string[] args)
        {
            Team team1 = new Team();
            Programmeur p1 = new Programmeur("Piet", Specialiteit.Csharp);
            team1.AddProgrammeur(p1);

           
            Console.ReadKey();
        }
    }
}

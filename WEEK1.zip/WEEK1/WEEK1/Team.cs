﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WEEK1
{
    public class Team
    {
        public Team()
        {

        }

        public void printalleteamleden()
        {
            Programmeur rohan = new Programmeur();
            rohan.naam = "Rohan van Wijk";
            rohan.specialiteit = Specialiteit.PHP.ToString();
            rohan.Print();

            Programmeur steve = new Programmeur();
            steve.naam = "Steve Jobs";
            steve.specialiteit = Specialiteit.Csharp.ToString();
            steve.Print();

            Programmeur bill = new Programmeur();
            bill.naam = "Bil Gates";
            bill.specialiteit = Specialiteit.HTML.ToString();
            bill.Print();

            Programmeur jan = new Programmeur();
            jan.naam = "Jan Kaas";
            jan.specialiteit = Specialiteit.Java.ToString();
            jan.Print();

            

        }
        
    }
}

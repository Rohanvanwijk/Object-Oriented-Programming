﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WEEK1
{
   public class Programmeur
    {
        // fields
        public string naam;
         public string specialiteit;

        // constructor
        public Programmeur()
        {
            naam = "";
            specialiteit = "";
        }

        // method
        public void Print()
        {
            Console.WriteLine("Naam: {0} - Vak: {1}", naam, specialiteit);
            
        }

    }
}

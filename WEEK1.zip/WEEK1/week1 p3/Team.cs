﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week1_p3
{
    public class Team
    {

        List<Programmeur> programmeurs = new List<Programmeur>();

        public Team()
        {

        }

        public void AddProgrammeur(Programmeur p)
        {
          
            p.naam = "roan";
            p.specialiteit = Specialiteit.Java;
            programmeurs.Add(p);
        }


        public void printalleteamleden()
        {
            foreach (Programmeur p in programmeurs)
            {
                Console.WriteLine(p);
            }
        }

    }
}

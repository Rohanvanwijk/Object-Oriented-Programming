﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week1_p3
{
    class Program
    {
        static void Main(string[] args)
        {
            Team team1 = new Team();
            
            team1.AddProgrammeur(new Programmeur("Piet", Specialiteit.Csharp));
            team1.AddProgrammeur(new Programmeur("Piet", Specialiteit.Csharp));
            team1.AddProgrammeur(new Programmeur("Piet", Specialiteit.Csharp));
            team1.AddProgrammeur(new Programmeur("Piet", Specialiteit.Csharp));

            team1.printalleteamleden();

            Console.ReadKey();
        }
    }
}

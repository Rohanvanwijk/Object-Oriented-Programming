﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week1_p3
{
    public class Programmeur
    {
        // fields
        public string naam;
        public Specialiteit specialiteit;

        // constructor
        public Programmeur(string n, Specialiteit s)
        {
            naam = n;
            specialiteit = s;
        }

        // method
        public void Print()
        {
            Console.WriteLine("Naam: {0} - Vak: {1}", naam, specialiteit);

        }

    }
}
